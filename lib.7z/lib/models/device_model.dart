class Device {
  final String id;
  final String name;
  final DeviceType type;
  bool state;
  int? value; // For servo angles (0-180)
  final String? icon;
  final String? room;
  final DateTime? lastUpdated;

  Device({
    required this.id,
    required this.name,
    required this.type,
    this.state = false,
    this.value,
    this.icon,
    this.room,
    this.lastUpdated,
  });

  factory Device.fromJson(Map<String, dynamic> json) {
    return Device(
      id: json['id'],
      name: json['name'],
      type: DeviceType.values.firstWhere(
        (e) => e.toString() == 'DeviceType.${json['type']}',
        orElse: () => DeviceType.relay,
      ),
      state: json['state'] ?? false,
      value: json['value'],
      icon: json['icon'],
      room: json['room'],
      lastUpdated: json['lastUpdated'] != null
          ? DateTime.parse(json['lastUpdated'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'type': type.toString().split('.').last,
      'state': state,
      'value': value,
      'icon': icon,
      'room': room,
      'lastUpdated': lastUpdated?.toIso8601String(),
    };
  }

  Device copyWith({
    String? id,
    String? name,
    DeviceType? type,
    bool? state,
    int? value,
    String? icon,
    String? room,
    DateTime? lastUpdated,
  }) {
    return Device(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      state: state ?? this.state,
      value: value ?? this.value,
      icon: icon ?? this.icon,
      room: room ?? this.room,
      lastUpdated: lastUpdated ?? this.lastUpdated,
    );
  }

  bool get isRelay => type == DeviceType.relay;
  bool get isServo => type == DeviceType.servo;
  bool get isOn => state;
  bool get isOff => !state;
}

enum DeviceType { relay, servo }
